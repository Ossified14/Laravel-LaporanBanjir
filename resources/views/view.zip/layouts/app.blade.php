<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    {{-- Judul halaman diisi dari masing-masing view child --}}
    <title>@yield('title', 'LaporBanjir') — BPBD Kab. Bandung</title>

    {{-- Stylesheet utama aplikasi LaporBanjir --}}
    <link rel="stylesheet" href="{{ asset('css/laporbanjir.css') }}">
</head>
<body>

    {{-- Wadah konten utama — tanpa header dan footer --}}
    <div class="page-wrapper">
        @yield('content')
    </div>

    {{-- JavaScript aplikasi LaporBanjir --}}
    <script src="{{ asset('js/laporbanjir.js') }}"></script>
</body>
</html>

